﻿#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>
#include <limits>
#include <string>


using namespace std;

// Функция f(x) = x^2 - sin(3x)
double f(double x) {
    return x * x - sin(3.0 * x);
}

// Уточнение корня методом бисекции на отрезке [a,b]
// Предполагается, что f(a)*f(b) <= 0
double bisect_root(double a, double b, double tol, int max_iter) {
    double fa = f(a), fb = f(b);
    if (fabs(fa) < tol) return a;
    if (fabs(fb) < tol) return b;

    for (int iter = 0; iter < max_iter; ++iter) {
        double m = 0.5 * (a + b);
        double fm = f(m);
        if (fabs(fm) < tol) return m;
        if (fa * fm <= 0) {
            b = m; fb = fm;
        }
        else {
            a = m; fa = fm;
        }
        if (fabs(b - a) < tol) return 0.5 * (a + b);
    }
    return 0.5 * (a + b); // вернем текущее приближение
}

int main() {
    setlocale(LC_ALL, "Russian");
    cout << fixed << setprecision(10);
    double X_start, X_end, h;
    double tol = 1e-10;
    int max_iter = 1000000;

    cout << "Найти нули функции f(x)=x^2 - sin(3x)\n";
    cout << "Введите X_start X_end h (например: -5 5 0.01): ";
    if (!(cin >> X_start >> X_end >> h)) {
        cerr << "[ОШИБКА] Неверный ввод.\n";
        return 1;
    }
    cout << "Введите точность tol (нажмите Enter для 1e-10): ";
    string tmp;
    getline(cin, tmp); // consume endline
    if (!getline(cin, tmp)) tmp = "";
    if (!tmp.empty()) tol = stod(tmp);

    if (h <= 0) {
        cerr << "[ОШИБКА] Шаг h должен быть > 0.\n";
        return 1;
    }
    if (X_end <= X_start) {
        cerr << "[ОШИБКА] X_end должен быть > X_start.\n";
        return 1;
    }

    vector<double> roots;
    double x = X_start;
    double prev_y = f(x);
    long long steps = 0;

    while (x + 1e-15 <= X_end && steps < max_iter) {
        double x_next = x + h;
        if (x_next > X_end) x_next = X_end;
        double curr_y = f(x_next);

        // случай: точное попадание
        if (fabs(prev_y) < tol) {
            double r = x;
            // защита от дублей
            bool dup = false;
            for (double rr : roots) if (fabs(rr - r) < tol * 10) { dup = true; break; }
            if (!dup) roots.push_back(r);
        }

        // смена знака => корень внутри [x, x_next]
        if (prev_y * curr_y < 0.0) {
            double r = bisect_root(x, x_next, tol, 1000);
            // проверка дублей
            bool dup = false;
            for (double rr : roots) if (fabs(rr - r) < 1e-8) { dup = true; break; }
            if (!dup) roots.push_back(r);
        }

        prev_y = curr_y;
        x = x_next;
        ++steps;
    }

    cout << "\n--- РЕЗУЛЬТАТ ---\n";
    if (roots.empty()) {
        cout << "Корней не найдено на заданном отрезке.\n";
    }
    else {
        cout << "Найдено корней: " << roots.size() << "\n";
        for (size_t i = 0; i < roots.size(); ++i) {
            cout << "x[" << i << "] = " << setprecision(12) << roots[i]
                << "   f(x) = " << setprecision(4) << f(roots[i]) << "\n";
        }
    }
    cout << "Шагов сканирования: " << steps << "\n";
    return 0;
}